#include "graph.hpp"
#include "ReaderException.hpp"
#include "utils/logger.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
/// \brief Fonction de lecture du fichier d'adjacence
/// \param inFile nom du fichier d'entr�e
/// \param m matrice d adjacence a remplir
/// \throws ReaderException when an error occurs

void reader(std::string inFile, AMatrix ** m, Graph ** g)
{
   int retour = 0;
   int nbPoint = 0, i1, i2;
   bool line_error = false;
   std::vector<int>  * peers;
   peers = new std::vector<int>();
   try
   {
      std::ifstream file(inFile.c_str());


      if( file.is_open() )
      {
	 nbPoint = retrieveNbPointFile(file);

	 file.clear();
	 file.seekg(0, std::ios::beg);//rembobine le lecteur de flux

	 std::ostringstream nb;
	 nb << nbPoint;
	 Logger::getInstance()->logMessage( "il y a " + nb.str() + " points dans le graph", Logger::DEBUG);

	 //fonction de creation des sommets dans le graphe
	 edge_descriptor e;
	 bool found = false;
	 *g = new Graph();
	 initVertex(*g, nbPoint);

	 //remplissage de la matrice
	 std::string line, tempString, linkType;

	 while(std::getline(file, line))
	 {
	    // std::cout << "je lis la ligne" << file.tellg() << std::endl;
	    std::istringstream lineStream(line);
	    if(lineStream >> tempString)
	    {
	       std::istringstream in1(tempString);
	       if(lineStream >> tempString)
	       {
		  std::istringstream in2(tempString);
		  if(lineStream >> linkType && in1 >> i1 && in2 >> i2)
		  {
		     addEdge(i1, i2, linkType, found, e, g, peers);
		     if(!found){
			line_error=true;
		     }
		  }else{
		     line_error=true;
		  }
	       }
	    }
	 }

	 file.close();

   std::cout << peers->size() << std::endl;
      }
      else{
	 throw ReaderException("Fichier inexistant ou non lisible", inFile,ReaderException::CRITICAL);
      }
   }
   catch(const std::exception & e)
   {
      throw ReaderException("Erreur lors de la lecture du fichier", inFile, ReaderException::CRITICAL);
   }
   if(line_error)
   {
      throw ReaderException("Erreur lors de la lecture d'une ou plusieurs ligne", inFile, ReaderException::NON_BLOCKING);
   }
}

/// \brief nombre de point contenu dans le fichier
/// \param inIf flux sur fichier d'entree
/// \return nombre de point contenu dans le fichier
int retrieveNbPointFile(std::ifstream & inIf)
{
   int retour = 0, i1, i2;

   std::string line, tempString;

   while(std::getline(inIf, line))
   {
      std::istringstream lineStream(line);

      if(lineStream >> tempString)
      {
	 std::istringstream in1(tempString);

	 if(lineStream >> tempString)
	 {
	    std::istringstream in2(tempString);

	    if(in1 >> i1 && in2 >> i2 )
	    {
	       if(retour < i1)
		  retour = i1;
	       if(retour < i2)
		  retour = i2;
	    }
	 }
      }
   }


   return retour + ZERO;
}

/// \brief cree les points du graphe
/// \param g pointeur sur le graphe
/// \param i nombre de points a creer
void initVertex(Graph * g, int i)
{
   for(int k = 0; k < i; ++k)
   {
      vertex_descriptor v1 = boost::add_vertex(*g);
      (*g)[v1].value = i;
   }
}

/// \brief Ajoute une arette
/// \param i1 index du premier point 
/// \param i2 index du deuxieme point
/// \param linkType descripteur du type d'arrete
/// \param found booleen resultat
/// \param e edge_descriptor de l'arrete
/// \param g double pointeur sur le Graph ou il faut ajouter la relation

void addEdge(int i1, int i2, std::string linkType, bool & found, edge_descriptor & e, Graph ** g, std::vector<int> * peers){

   vertex_descriptor v = boost::vertex(i1,**g);
   vertex_descriptor vv = boost::vertex(i2,**g);
   //si on veut mettre des poids
   // 		if(found) (**g)[e].weight = xx%13 * 2 + 5;
   if(linkType=="PEER"){	
      boost::tie(e,found) = boost::add_edge( v,vv,**g);
      boost::tie(e,found) = boost::add_edge(vv,v,**g);
      //TODO trouver structure pour faire un autre arbre tout en gardant la liaison entre le chiffre et la cle...
      addToPeersVector(peers, i1, i2);
      // Client vers Peer si inverse inverser les v et les vv dans la parenthese de add_edge
   }else if(linkType=="C2P"){
      boost::tie(e,found) = boost::add_edge(v,vv,**g);
   }else if(linkType=="P2C"){
      boost::tie(e,found) = boost::add_edge(vv,v,**g);
   }
}

void addToPeersVector(std::vector<int> * peers, int i1, int i2){
   bool i1here=false, i2here=false;
   std::vector<int>::iterator it;
   for(it = peers->begin(); it<peers->end(); it++){
      if(*it == i1) i1here= true;
      if(*it == i2) i2here=true;
   }
   if(!i1here) peers->push_back(i1);
   if(!i2here) peers->push_back(i2);
}
